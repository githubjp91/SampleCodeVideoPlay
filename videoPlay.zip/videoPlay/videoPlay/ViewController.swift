//
//  ViewController.swift
//  videoPlay
//
//  Created by Mac on 6/19/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit


class ViewController: UIViewController {

    var videoPlayer:AVPlayer = AVPlayer()
    
    
    @IBOutlet weak var videoPlayerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func playLocal(_ sender: UIButton)
    {
        guard let Videopath = Bundle.main.path(forResource: "ladki", ofType: ".3gp")
                else
                {
                    debugPrint("connection error")
                    return
                }
        
     
        videoPlayer = AVPlayer(url: URL(fileURLWithPath: Videopath))
        let playerLayer = AVPlayerLayer(player: videoPlayer)
        playerLayer.frame = videoPlayerView.bounds
        videoPlayerView.layer.addSublayer(playerLayer)
        videoPlayer.play()
        
    }
    
    @IBAction func playURL(_ sender: UIButton)
    {
        let videoURL = URL(string: "https://www.youtube.com/watch?v=YjkSwU1BQe4")
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        
        playerViewController.player = player
        //self.present(playerViewController, animated: true)
        self.present(playerViewController, animated: true)
        {
        playerViewController.player!.play()
        }
        
        

       }
  
    }

    



